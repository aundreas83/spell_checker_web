#import requests

#web_app_server = "http://127.0.0.1:5000"
#login = web_app_server + "/login"

#pload = {'uname':'script','pword':'1234','
