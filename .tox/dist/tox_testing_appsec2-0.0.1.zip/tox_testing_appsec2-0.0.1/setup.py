from setuptools import find_packages, setup
setup(
    name="tox_testing_appsec2",
    version="0.0.1",
    description = "For Assignments in CS-GY9163: Application Security",
    packages=find_packages(),
)
